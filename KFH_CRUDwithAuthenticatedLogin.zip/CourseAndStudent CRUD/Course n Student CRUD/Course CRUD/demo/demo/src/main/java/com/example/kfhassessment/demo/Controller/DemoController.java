package com.example.kfhassessment.demo.Controller;

import com.example.kfhassessment.demo.entity.Course;
import com.example.kfhassessment.demo.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.concurrent.Callable;

@Controller
    @RequestMapping("/courses")
    public class DemoController {

        private CourseService thecourseService;

        @Autowired
        public DemoController(CourseService mycourseservice) {
            thecourseService = mycourseservice;
        }


        @GetMapping("/list")
        public String listCourse(Model theModel){
            List<Course> thecourse=thecourseService.findAll();
            theModel.addAttribute("courses",thecourse);
            return "courses/list-courses";

        }


        @GetMapping("/showformforadd")
        public String showformforadd(Model themodel){
            Course thecourse=new Course();
            themodel.addAttribute("course",thecourse);
            return "courses/course-form";
        }


       @PostMapping("/save")
       public String savecourse(@ModelAttribute("course") Course thecourse){
            thecourseService.save(thecourse);
            return "redirect:/courses/list";
       }


       @GetMapping("/showformforupdate")
       public String showformforupdate(@RequestParam("courseid") int theId, Model theModel){
            Course thecourse=thecourseService.findById(theId);
            theModel.addAttribute("course",thecourse);
            return "courses/course-form";
       }


       @GetMapping("/delete")
    public String delete(@RequestParam("courseid") int theId){
            thecourseService.deleteById(theId);
            return "redirect:/courses/list";
       }


    }

