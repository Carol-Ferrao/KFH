package com.example.kfhassessment.demo.service;


import com.example.kfhassessment.demo.entity.Course;

import java.util.List;

public interface CourseService {

    List<Course> findAll();

    Course findById(int theId);

    Course save(Course theEmployee);

    void deleteById(int theId);

}
