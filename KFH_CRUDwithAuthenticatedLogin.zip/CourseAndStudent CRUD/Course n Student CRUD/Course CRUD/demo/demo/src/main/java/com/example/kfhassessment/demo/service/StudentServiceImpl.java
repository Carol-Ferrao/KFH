package com.example.kfhassessment.demo.service;

import com.example.kfhassessment.demo.dao.CourseRepository;
import com.example.kfhassessment.demo.dao.StudentRepository;
import com.example.kfhassessment.demo.entity.Course;
import com.example.kfhassessment.demo.entity.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StudentServiceImpl implements StudentService{
        private StudentRepository thestudentrepository;

        @Autowired
        public StudentServiceImpl(StudentRepository mystudentrepository) {
        thestudentrepository = mystudentrepository;
        }

    @Override
    public List<Student> findAll() {
        return thestudentrepository.findAll();
    }

    @Override
    public Student save(Student thestudent) {
            return thestudentrepository.save(thestudent);
    }



    @Override
    public Student findById(int theId) {
        Optional<Student> result = thestudentrepository.findById(theId);

        Student thestudent = null;

        if (result.isPresent()) {
            thestudent = result.get();
        }
        else {
            // we didn't find the employee
            throw new RuntimeException("Did not find student id - " + theId);
        }

        return thestudent;
    }


    @Override
    public void deleteById(int theId) {
        thestudentrepository.deleteById(theId);
    }



}
