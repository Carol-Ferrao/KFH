package com.example.kfhassessment.demo.service;

import com.example.kfhassessment.demo.entity.Course;
import com.example.kfhassessment.demo.entity.Student;

import java.util.List;

public interface StudentService {

    List<Student> findAll();
    Student save(Student thestudent);

    Student findById(int theId);

    void deleteById(int theId);


}
