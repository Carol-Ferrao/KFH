package com.example.kfhassessment.demo.Controller;


import com.example.kfhassessment.demo.entity.Course;
import com.example.kfhassessment.demo.entity.Student;
import com.example.kfhassessment.demo.service.CourseService;
import com.example.kfhassessment.demo.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Controller
@RequestMapping("/students")
public class StudentController {

    private StudentService thestudentservice;
   // private CourseService thecourseservice;

    @Autowired
    public StudentController(StudentService mystudentservice) {
        thestudentservice = mystudentservice;
    }


    @GetMapping("/display")
    public String listStudents(Model theModel){
        List<Student> thestudent=thestudentservice.findAll();
        theModel.addAttribute("students",thestudent);
        return "courses/list-students";

    }


    @GetMapping("/showformforadd")
    public String showformforadd(Model themodel){
        Student thestudent=new Student();
        themodel.addAttribute("student",thestudent);
        return "courses/student-form";
    }


    @GetMapping("/showformforupdate")
    public String showformforupdate(@RequestParam("studentid") int theId, Model theModel){
        Student thestudent=thestudentservice.findById(theId);
        theModel.addAttribute("student",thestudent);
        return "courses/student-form";
    }

    @PostMapping("/save")
    public String savestudent(@ModelAttribute("student") Student thestudent){
        thestudentservice.save(thestudent);
        return "redirect:/students/display";
    }


    @GetMapping("/delete")
    public String delete(@RequestParam("studentid") int theId){
        thestudentservice.deleteById(theId);
        return "redirect:/students/display";
    }


}
