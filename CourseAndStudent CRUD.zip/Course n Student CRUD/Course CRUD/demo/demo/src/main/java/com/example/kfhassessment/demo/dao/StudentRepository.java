package com.example.kfhassessment.demo.dao;

import com.example.kfhassessment.demo.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<Student,Integer> {
}
