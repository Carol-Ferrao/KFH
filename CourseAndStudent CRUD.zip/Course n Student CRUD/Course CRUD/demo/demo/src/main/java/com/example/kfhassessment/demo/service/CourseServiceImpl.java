package com.example.kfhassessment.demo.service;

import com.example.kfhassessment.demo.dao.CourseRepository;
import com.example.kfhassessment.demo.entity.Course;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.Callable;

@Service
public class CourseServiceImpl implements CourseService {

    private CourseRepository thecourserepository;

    @Autowired
    public CourseServiceImpl(CourseRepository mycourserepository) {
        thecourserepository = mycourserepository;
    }

    @Override
    public List<Course> findAll() {
        return thecourserepository.findAll();
    }

    @Override
    public Course findById(int theId) {
        Optional<Course> result = thecourserepository.findById(theId);

        Course thecourse = null;

        if (result.isPresent()) {
            thecourse = result.get();
        }
        else {
            // we didn't find the employee
            throw new RuntimeException("Did not find course id - " + theId);
        }

        return thecourse;
    }

    @Override
    public Course save(Course theEmployee) {
        return thecourserepository.save(theEmployee);
    }

    @Override
    public void deleteById(int theId) {
        thecourserepository.deleteById(theId);
    }
}

